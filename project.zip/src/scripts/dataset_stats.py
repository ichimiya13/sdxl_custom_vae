"""
UWF マルチラベルデータセットの統計を表示するスクリプト。

想定するデータ構造 (image_dataset.MultiLabelMedicalDataset と同じ):
  root/
    ├── default_split.yaml
    ├── <image0>.png
    ├── <image0>.yaml
    └── ...

default_split.yaml は以下のような split 名 -> 画像ファイル名のリストを持つ YAML:
  train:
    - xxx.png
    - ...
  val:
    - ...
  test:
    - ...

各 <image>.yaml は {class_name: 0/1} の dict。

このスクリプトでは
  - split ごとのサンプル数
  - 各クラスの陽性サンプル数（split 別／全体）
  - クラスが欠落しているラベル数や欠損ファイル
を集計して標準出力に表示する。

使い方の例:
  python -m src.scripts.dataset_stats \
      --root ../data/uwf/multilabel/MedicalCheckup/splitted \
      --split-file default_split.yaml \
      --classes H1 H2 H3 H4 DME nAMD

  # config YAML (recon_pretrained_val_4ch など) から root / classes を流用する場合
  python -m src.scripts.dataset_stats \
      --config configs/vae/reconstruct/recon_pretrained_val_4ch.yaml
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple

import numpy as np
from PIL import Image
import yaml
from tqdm import tqdm
import unicodedata


DEFAULT_DATA_ROOT = (
    Path(__file__).resolve().parents[2]
    / "../data/uwf/multilabel/MedicalCheckup/splitted"
)

try:  # PyYAML C実装があれば優先
    from yaml import CSafeLoader as YamlLoader  # type: ignore
except Exception:  # pragma: no cover - fallback
    from yaml import SafeLoader as YamlLoader


def escape_non_ascii(text: str) -> str:
    """漢字など非ASCIIを "\\uXXXX" 形式で表示するユーティリティ"""
    return text.encode("unicode_escape").decode("ascii")


def load_yaml(path: Path) -> Mapping:
    with path.open("r", encoding="utf-8") as f:
        return yaml.load(f, Loader=YamlLoader)


def load_schema(schema_path: Path) -> tuple[List[str], Dict[str, List[str]], str]:
    """schema YAML: expects 'classes' (list) and optional 'label_groups' (dict).

    Returns: (classes, group_map, group_reduce)
    group_reduce is str (e.g., "any"), default "any".
    """

    if not schema_path.is_file():
        raise FileNotFoundError(f"Schema not found: {schema_path}")
    data = load_yaml(schema_path)
    if not isinstance(data, Mapping):
        raise ValueError(f"Invalid schema format: {schema_path}")

    cls_list = data.get("classes")
    if not isinstance(cls_list, list) or len(cls_list) == 0:
        raise ValueError(f"Schema must contain non-empty 'classes': {schema_path}")
    classes = [str(c) for c in cls_list]

    lg = data.get("label_groups", {}) or {}
    if not isinstance(lg, Mapping):
        raise ValueError(f"'label_groups' must be mapping in schema: {schema_path}")
    group_map = {str(k): [str(x) for x in v] for k, v in lg.items()}

    group_reduce = str(data.get("group_reduce", "any"))
    return classes, group_map, group_reduce


def normalize_split_dict(split_dict: Mapping[str, Iterable]) -> Dict[str, List[str]]:
    normalized: Dict[str, List[str]] = {}
    for key, value in split_dict.items():
        if not isinstance(value, Iterable):
            raise ValueError(f"Split '{key}' must be a list, got {type(value)}")
        normalized[key] = list(value)
    if not normalized:
        raise ValueError("Split file is empty. At least one split is required.")
    return normalized


def resolve_config(
    args: argparse.Namespace,
) -> tuple[Path, Path, Optional[List[str]]]:
    """優先順位: CLI 指定 > config YAML > デフォルト値"""

    cfg_root: Optional[Path] = None

    if args.config is not None:
        cfg = load_yaml(args.config)
        data_cfg = cfg.get("data", {}) if isinstance(cfg, dict) else {}
        cfg_root_val = data_cfg.get("root")
        if cfg_root_val:
            cfg_root = Path(cfg_root_val)

    if args.root is not None:
        root = Path(args.root)
    elif cfg_root is not None:
        root = cfg_root
    else:
        root = DEFAULT_DATA_ROOT

    # クラスはデフォルトでラベル YAML から自動推定する。
    # 明示的に --classes を指定したときのみ固定リストを利用する。
    classes: Optional[List[str]] = list(args.classes) if args.classes else None

    if args.split_file is not None:
        split_file = Path(args.split_file)
    else:
        split_file = root / "default_split.yaml"

    return root, split_file, classes


def ensure_all_classes(
    counters: MutableMapping[str, Counter], class_list: Sequence[str]
) -> None:
    for split_counter in counters.values():
        for cls in class_list:
            _ = split_counter[cls]


def compute_stats(
    root: Path,
    split_file: Path,
    classes: Optional[Sequence[str]] = None,
    label_suffix: str = ".yaml",
    show_progress: bool = True,
    calc_mean_std: bool = False,
    num_workers: Optional[int] = None,
    exclude_classes: Optional[Sequence[str]] = None,
    group_map: Optional[Mapping[str, Sequence[str]]] = None,
    group_reduce: str = "any",
    allowed_labels: Optional[Sequence[str]] = None,
):
    if not split_file.is_file():
        raise FileNotFoundError(f"Split file not found: {split_file}")
    if not root.is_dir():
        raise FileNotFoundError(f"Data root not found: {root}")

    split_dict_raw = load_yaml(split_file)
    if not isinstance(split_dict_raw, Mapping):
        raise ValueError(f"Invalid split file format: {split_file}")
    split_dict = normalize_split_dict(split_dict_raw)

    provided_classes = list(classes) if classes else None
    class_set = set(provided_classes) if provided_classes else set()
    exclude_set = set(exclude_classes) if exclude_classes else set()
    allowed_set = set(allowed_labels) if allowed_labels else None

    split_sample_counts: Dict[str, int] = {k: len(v) for k, v in split_dict.items()}
    valid_samples: Dict[str, int] = defaultdict(int)
    class_pos_counts: Dict[str, Counter] = defaultdict(Counter)
    missing_class_counts: Dict[str, Counter] = defaultdict(Counter)
    missing_images: Dict[str, List[str]] = defaultdict(list)
    missing_labels: Dict[str, List[str]] = defaultdict(list)
    invalid_labels: Dict[str, List[str]] = defaultdict(list)
    unknown_label_counts: Dict[str, Counter] = defaultdict(Counter)
    unknown_label_samples: Dict[str, int] = defaultdict(int)
    unknown_only_samples: Dict[str, int] = defaultdict(int)
    unknown_with_schema_samples: Dict[str, int] = defaultdict(int)
    unknown_label_counts_only: Dict[str, Counter] = defaultdict(Counter)
    unknown_label_counts_with_schema: Dict[str, Counter] = defaultdict(Counter)
    unknown_schema_pos_counts: Dict[str, Counter] = defaultdict(Counter)
    unknown_schema_co_counts: Dict[str, Dict[str, Counter]] = defaultdict(
        lambda: defaultdict(Counter)
    )

    mean_sum: Dict[str, np.ndarray] = defaultdict(lambda: np.zeros(3, dtype=np.float64))
    mean_sumsq: Dict[str, np.ndarray] = defaultdict(lambda: np.zeros(3, dtype=np.float64))
    mean_pix: Dict[str, int] = defaultdict(int)

    entries = [(s, f) for s, files in split_dict.items() for f in files]
    total_files = len(entries)
    progress = tqdm(total=total_files, disable=not show_progress, desc="Scanning")

    def reduce_group(values: List[float]) -> float:
        if not values:
            return float("nan")
        if group_reduce == "any":
            return 1.0 if any(v != 0 for v in values) else 0.0
        if group_reduce == "all":
            return 1.0 if all(v != 0 for v in values) else 0.0
        # fallback to any
        return 1.0 if any(v != 0 for v in values) else 0.0

    def process_file(split_name: str, fname: str):
        img_path = root / fname
        if not img_path.is_file():
            return {
                "split": split_name,
                "missing_image": str(img_path),
            }

        label_path = img_path.with_suffix(label_suffix)
        if not label_path.is_file():
            return {
                "split": split_name,
                "missing_label": str(label_path),
            }

        try:
            label_dict = load_yaml(label_path)
        except Exception as e:  # pragma: no cover - YAML error surface only at runtime
            return {
                "split": split_name,
                "invalid_label": f"{label_path} ({e})",
            }

        if not isinstance(label_dict, Mapping):
            return {
                "split": split_name,
                "invalid_label": f"{label_path} (expected mapping, got {type(label_dict)})",
            }

        label_keys = list(label_dict.keys())

        if allowed_set is not None:
            unknown_keys = [k for k in label_keys if k not in allowed_set]
            has_unknown_pos = False
            any_schema_pos = False
            schema_classes_set = set(provided_classes or [])
            for uk in unknown_keys:
                try:
                    v_uk = float(label_dict.get(uk, 0))
                except Exception:
                    return {
                        "split": split_name,
                        "invalid_label": f"{label_path} (class '{uk}' value not numeric)",
                    }
                if v_uk != 0:
                    has_unknown_pos = True
                    unknown_label_counts[split_name][uk] += 1

            if has_unknown_pos:
                # スキーマ内ラベルで陽性があるかを確認
                schema_pos_labels: List[str] = []
                for sc in schema_classes_set:
                    if sc not in label_dict:
                        continue
                    try:
                        if float(label_dict.get(sc, 0)) != 0:
                            any_schema_pos = True
                            schema_pos_labels.append(sc)
                    except Exception:
                        return {
                            "split": split_name,
                            "invalid_label": f"{label_path} (class '{sc}' value not numeric)",
                        }
                unknown_label_samples[split_name] += 1
                if any_schema_pos:
                    unknown_with_schema_samples[split_name] += 1
                    for uk in unknown_keys:
                        try:
                            if float(label_dict.get(uk, 0)) != 0:
                                unknown_label_counts_with_schema[split_name][uk] += 1
                                for sp in schema_pos_labels:
                                    unknown_schema_pos_counts[split_name][sp] += 1
                                    unknown_schema_co_counts[split_name][uk][sp] += 1
                        except Exception:
                            return {
                                "split": split_name,
                                "invalid_label": f"{label_path} (class '{uk}' value not numeric)",
                            }
                else:
                    unknown_only_samples[split_name] += 1
                    for uk in unknown_keys:
                        try:
                            if float(label_dict.get(uk, 0)) != 0:
                                unknown_label_counts_only[split_name][uk] += 1
                        except Exception:
                            return {
                                "split": split_name,
                                "invalid_label": f"{label_path} (class '{uk}' value not numeric)",
                            }

        local_missing_class = Counter()
        local_class_pos = Counter()

        target_classes = provided_classes if provided_classes else label_dict.keys()

        def get_value(cls: str):
            if cls in label_dict:
                try:
                    return float(label_dict[cls])
                except Exception:
                    return {
                        "error": f"{label_path} (class '{cls}' value not numeric)"
                    }
            if group_map and cls in group_map:
                vals: List[float] = []
                for src in group_map[cls]:
                    if src not in label_dict:
                        continue
                    try:
                        vals.append(float(label_dict[src]))
                    except Exception:
                        return {
                            "error": f"{label_path} (class '{src}' value not numeric)"
                        }
                if not vals:
                    return None  # treat as missing
                return reduce_group(vals)
            return None  # missing

        for cls in target_classes:
            v = get_value(cls)
            if isinstance(v, dict) and "error" in v:
                return {"split": split_name, "invalid_label": v["error"]}
            if v is None:
                local_missing_class[cls] += 1
                continue
            if v != 0:
                local_class_pos[cls] += 1

        mean_tuple: Optional[Tuple[float, float, float]] = None
        meansq_tuple: Optional[Tuple[float, float, float]] = None
        pix_count = 0

        if calc_mean_std:
            try:
                with Image.open(img_path) as img:
                    img = img.convert("RGB")
                    arr = np.asarray(img, dtype=np.float64) / 255.0
            except Exception as e:  # pragma: no cover - rare I/O errors
                return {
                    "split": split_name,
                    "invalid_label": f"{img_path} (image read error: {e})",
                }

            if arr.ndim != 3 or arr.shape[2] != 3:
                return {
                    "split": split_name,
                    "invalid_label": f"{img_path} (unexpected shape {arr.shape}, expected HxWx3)",
                }

            h, w, _ = arr.shape
            pix_count = h * w
            reshaped = arr.reshape(-1, 3)
            sum_v = reshaped.sum(axis=0)
            sumsq_v = (reshaped * reshaped).sum(axis=0)
            mean_tuple = tuple(sum_v.tolist())
            meansq_tuple = tuple(sumsq_v.tolist())

        return {
            "split": split_name,
            "label_keys": label_keys,
            "missing_class": local_missing_class,
            "class_pos": local_class_pos,
            "valid": True,
            "mean_sum": mean_tuple,
            "mean_sumsq": meansq_tuple,
            "mean_pix": pix_count,
        }

    max_workers = num_workers if num_workers is not None else None
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = [ex.submit(process_file, s, f) for s, f in entries]
        for fut in as_completed(futures):
            res = fut.result()
            split_name = res["split"]

            missing_img = res.get("missing_image")
            if missing_img:
                missing_images[split_name].append(missing_img)
                progress.update(1)
                continue

            missing_lbl = res.get("missing_label")
            if missing_lbl:
                missing_labels[split_name].append(missing_lbl)
                progress.update(1)
                continue

            invalid_lbl = res.get("invalid_label")
            if invalid_lbl:
                invalid_labels[split_name].append(invalid_lbl)
                progress.update(1)
                continue

            if provided_classes is None:
                class_set.update(res.get("label_keys", []))
                if group_map:
                    class_set.update(group_map.keys())

            valid_samples[split_name] += 1

            class_pos_counts[split_name].update(res.get("class_pos", {}))
            missing_class_counts[split_name].update(res.get("missing_class", {}))

            if calc_mean_std and res.get("mean_pix", 0) > 0:
                pix = res["mean_pix"]
                mean_pix[split_name] += pix
                mean_pix["all"] += pix

                sum_v = np.array(res["mean_sum"], dtype=np.float64)
                sumsq_v = np.array(res["mean_sumsq"], dtype=np.float64)
                mean_sum[split_name] += sum_v
                mean_sumsq[split_name] += sumsq_v
                mean_sum["all"] += sum_v
                mean_sumsq["all"] += sumsq_v

            progress.update(1)

    progress.close()
    class_list = sorted(class_set) if not provided_classes else list(provided_classes)
    ensure_all_classes(class_pos_counts, class_list)
    ensure_all_classes(missing_class_counts, class_list)

    def finalize_mean_std(split_key: str):
        pix = mean_pix.get(split_key, 0)
        if pix == 0:
            return None
        mean = mean_sum[split_key] / pix
        var = mean_sumsq[split_key] / pix - mean * mean
        var = np.clip(var, 0.0, None)
        std = np.sqrt(var)
        return mean.tolist(), std.tolist()

    mean_std = {
        k: finalize_mean_std(k)
        for k in list(mean_pix.keys())
    } if calc_mean_std else None

    return {
        "class_list": class_list,
        "split_sample_counts": split_sample_counts,
        "valid_samples": dict(valid_samples),
        "class_pos_counts": dict(class_pos_counts),
        "missing_class_counts": dict(missing_class_counts),
        "missing_images": dict(missing_images),
        "missing_labels": dict(missing_labels),
        "invalid_labels": dict(invalid_labels),
        "mean_std": mean_std,
        "exclude_classes": list(exclude_set),
        "unknown_label_counts": dict(unknown_label_counts),
        "unknown_label_samples": dict(unknown_label_samples),
        "unknown_only_samples": dict(unknown_only_samples),
        "unknown_with_schema_samples": dict(unknown_with_schema_samples),
        "unknown_label_counts_only": dict(unknown_label_counts_only),
        "unknown_label_counts_with_schema": dict(unknown_label_counts_with_schema),
        "unknown_schema_pos_counts": dict(unknown_schema_pos_counts),
        "unknown_schema_co_counts": {
            split: dict(v) for split, v in unknown_schema_co_counts.items()
        },
    }


def _disp_width(text: str) -> int:
    width = 0
    for ch in text:
        if unicodedata.category(ch) in {"Mn", "Me", "Cf"}:
            continue  # zero width combining/format chars
        ea = unicodedata.east_asian_width(ch)
        if ea in {"F", "W"}:  # Fullwidth / Wide
            width += 2
        else:
            width += 1
    return width


def _pad_cell(text: str, width: int) -> str:
    pad = width - _disp_width(text)
    return text + (" " * max(pad, 0))


def format_table(rows: List[List[str]]) -> str:
    # rows: List of row (list of strings)
    cols = list(zip(*rows))
    col_widths = [max(_disp_width(str(cell)) for cell in col) for col in cols]

    lines = []
    for r_idx, row in enumerate(rows):
        cells = [_pad_cell(str(cell), col_widths[i]) for i, cell in enumerate(row)]
        line = " | ".join(cells)
        lines.append(line)
        if r_idx == 0:
            sep = "-+-".join("-" * w for w in col_widths)
            lines.append(sep)
    return "\n".join(lines)


def print_summary(
    root: Path,
    split_file: Path,
    stats: Mapping[str, object],
    sort_by: str = "total",
):
    class_list: List[str] = stats["class_list"]
    split_sample_counts: Mapping[str, int] = stats["split_sample_counts"]
    valid_samples: Mapping[str, int] = stats["valid_samples"]
    class_pos_counts: Mapping[str, Counter] = stats["class_pos_counts"]
    missing_class_counts: Mapping[str, Counter] = stats["missing_class_counts"]
    missing_images: Mapping[str, List[str]] = stats["missing_images"]
    missing_labels: Mapping[str, List[str]] = stats["missing_labels"]
    invalid_labels: Mapping[str, List[str]] = stats["invalid_labels"]
    mean_std = stats.get("mean_std")
    exclude_classes: List[str] = stats.get("exclude_classes", [])
    unknown_label_counts: Mapping[str, Counter] = stats.get("unknown_label_counts", {})
    unknown_label_samples: Mapping[str, int] = stats.get("unknown_label_samples", {})
    unknown_only_samples: Mapping[str, int] = stats.get("unknown_only_samples", {})
    unknown_with_schema_samples: Mapping[str, int] = stats.get("unknown_with_schema_samples", {})
    unknown_label_counts_only: Mapping[str, Counter] = stats.get("unknown_label_counts_only", {})
    unknown_label_counts_with_schema: Mapping[str, Counter] = stats.get("unknown_label_counts_with_schema", {})
    unknown_schema_pos_counts: Mapping[str, Counter] = stats.get("unknown_schema_pos_counts", {})
    unknown_schema_co_counts: Mapping[str, Mapping[str, Counter]] = stats.get(
        "unknown_schema_co_counts", {}
    )

    splits = list(split_sample_counts.keys())

    print("=== Dataset info ===")
    print(f"root       : {root}")
    print(f"split file : {split_file}")
    print()

    print("=== Sample counts (per split) ===")
    for split in splits:
        total = split_sample_counts[split]
        valid = valid_samples.get(split, 0)
        print(f"{split:10s}: {total:5d} files (valid labels: {valid})")
    print()

    header = ["class"] + [f"{s} (+)" for s in splits] + ["total (+)", "ratio (total)"]
    rows: List[List[str]] = [header]

    total_valid = sum(valid_samples.values()) or 1
    sort_target = sort_by
    if sort_by != "total" and sort_by not in splits:
        print(f"[info] sort_by='{sort_by}' は split に存在しないため 'total' でソートします")
        sort_target = "total"

    def cls_sort_key(cls: str):
        if sort_target == "total":
            primary = sum(class_pos_counts.get(s, {}).get(cls, 0) for s in splits)
        else:
            primary = class_pos_counts.get(sort_target, {}).get(cls, 0)

        total_pos = sum(class_pos_counts.get(s, {}).get(cls, 0) for s in splits)
        return (-primary, -total_pos, cls)

    for cls in sorted(class_list, key=cls_sort_key):
        row = [cls]
        cls_total = 0
        for split in splits:
            cnt = class_pos_counts.get(split, {}).get(cls, 0)
            row.append(str(cnt))
            cls_total += cnt
        ratio = cls_total / total_valid
        row.append(str(cls_total))
        row.append(f"{ratio:.4f}")
        rows.append(row)

    print("=== Positive label counts ===")
    print(format_table(rows))
    print()

    if mean_std:
        print("=== Image mean / std (RGB, [0,1]) ===")
        header_ms = ["split", "mean (R,G,B)", "std (R,G,B)"]
        rows_ms: List[List[str]] = [header_ms]
        for split in list(split_sample_counts.keys()) + (["all"] if "all" in mean_std else []):
            val = mean_std.get(split)
            if val is None:
                continue
            mean_v, std_v = val
            def fmt(vec):
                return "(" + ", ".join(f"{x:.6f}" for x in vec) + ")"
            rows_ms.append([split, fmt(mean_v), fmt(std_v)])
        print(format_table(rows_ms))
        print()

    any_missing_classes = any(c for c in missing_class_counts.values())
    if any_missing_classes:
        print("=== Missing class entries (label YAML lacked the key) ===")
        for split in splits:
            miss_counter = missing_class_counts.get(split, {})
            if not miss_counter:
                continue
            print(f"[{split}]")
            for cls, cnt in miss_counter.items():
                if cnt > 0:
                    print(f"  {cls}: {cnt}")
        print()

    # 平均陽性率（除外クラスを除く）
    filtered_classes = [c for c in class_list if c not in exclude_classes]
    if filtered_classes:
        print("=== Mean positive rate per class (excluding: " + ", ".join(exclude_classes) + ") ===")
        header_rate = ["class", "overall (+, rate)"] + [f"{s} (+, rate)" for s in splits]
        rows_rate: List[List[str]] = [header_rate]
        total_valid_all = sum(valid_samples.values()) or 1
        per_class_overall_rates: List[float] = []
        per_class_split_rates: Dict[str, List[float]] = {s: [] for s in splits}

        for cls in sorted(filtered_classes, key=cls_sort_key):
            row = [cls]
            total_pos = sum(class_pos_counts.get(s, {}).get(cls, 0) for s in splits)
            overall_rate = total_pos / total_valid_all
            row.append(f"{total_pos} ({overall_rate:.4f})")
            per_class_overall_rates.append(overall_rate)

            for split in splits:
                vs = valid_samples.get(split, 0)
                cnt = class_pos_counts.get(split, {}).get(cls, 0)
                rate = cnt / vs if vs else 0.0
                per_class_split_rates[split].append(rate)
                row.append(f"{cnt} ({rate:.4f})")
            rows_rate.append(row)
        print(format_table(rows_rate))
        print()

        # 各ラベル陽性率の要約統計
        def rate_summary(values: List[float]) -> Tuple[str, str, str]:
            if not values:
                return ("N/A", "N/A", "N/A")
            arr = np.array(values, dtype=np.float64)
            return (
                f"{np.median(arr):.4f}",
                f"{arr.min():.4f}",
                f"{arr.max():.4f}",
            )

        print("=== Positive rate summary per class (excluding: " + ", ".join(exclude_classes) + ") ===")
        header_summary = ["scope", "median", "min", "max"]
        rows_summary: List[List[str]] = [header_summary]

        med, mn, mx = rate_summary(per_class_overall_rates)
        rows_summary.append(["overall", med, mn, mx])

        for split in splits:
            med, mn, mx = rate_summary(per_class_split_rates.get(split, []))
            rows_summary.append([split, med, mn, mx])

        print(format_table(rows_summary))
        print()

    # 1サンプルあたりの平均陽性クラス数（除外クラスを除く）
    if filtered_classes:
        print("=== Avg positive classes per sample (excluding: " + ", ".join(exclude_classes) + ") ===")
        def total_pos_split(split: str):
            return sum(class_pos_counts.get(split, {}).get(cls, 0) for cls in filtered_classes)

        total_valid_all = sum(valid_samples.values()) or 1
        total_pos_all = sum(total_pos_split(s) for s in splits)
        overall_avg = total_pos_all / total_valid_all
        print(f"overall: {overall_avg:.4f}")
        for split in splits:
            vs = valid_samples.get(split, 0)
            pos = total_pos_split(split)
            avg = pos / vs if vs else 0.0
            print(f"{split}: {avg:.4f}")
        print()

    def print_issue(title: str, issues: Mapping[str, List[str]]):
        has_issue = any(v for v in issues.values())
        if not has_issue:
            return
        print(f"=== {title} ===")
        for split in splits:
            items = issues.get(split, [])
            if items:
                print(f"[{split}] {len(items)} items")
                for item in items:
                    print(f"  - {item}")
        print()

    print_issue("Missing image files", missing_images)
    print_issue("Missing label files", missing_labels)
    print_issue("Invalid label YAML", invalid_labels)

    # スキーマ外ラベルのサマリ（陽性のみカウント）
    if any(unknown_label_samples.values()) or any(unknown_label_counts.values()):
        print("=== Unknown labels (not in schema/classes, positive only) ===")
        for split in splits:
            ns = unknown_label_samples.get(split, 0)
            if ns == 0:
                continue
            only_ns = unknown_only_samples.get(split, 0)
            with_ns = unknown_with_schema_samples.get(split, 0)
            print(f"[{split}] {ns} samples contain positive unknown labels (schema positiveなし: {only_ns}, あり: {with_ns})")
            cnts = unknown_label_counts.get(split, {})
            for lbl, c in cnts.most_common():
                print(f"  {lbl}: {c}")
            cnts_only = unknown_label_counts_only.get(split, {})
            cnts_with = unknown_label_counts_with_schema.get(split, {})
            if cnts_only:
                print("  -- 内訳: schema positiveなし")
                for lbl, c in cnts_only.most_common():
                    print(f"    {lbl}: {c}")
            if cnts_with:
                print("  -- 内訳: schema positiveあり")
                for lbl, c in cnts_with.most_common():
                    print(f"    {lbl}: {c}")
            co_schema = unknown_schema_pos_counts.get(split, {})
            if co_schema:
                print("  -- 共起したスキーマ内陽性クラス")
                for lbl, c in co_schema.most_common():
                    print(f"    {lbl}: {c}")
            co_by_label = unknown_schema_co_counts.get(split, {})
            if co_by_label:
                print("  -- ラベル別の共起スキーマ内陽性クラス")
                for uk, cnts in sorted(
                    co_by_label.items(),
                    key=lambda kv: sum(kv[1].values()),
                    reverse=True,
                ):
                    total = sum(cnts.values())
                    print(f"    [{uk}] 合計: {total}")
                    for lbl, c in cnts.most_common():
                        print(f"      {lbl}: {c}")
        print()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="UWF multi-label dataset statistics")
    parser.add_argument(
        "--root",
        type=Path,
        default=None,
        help=(
            "データセットのルートディレクトリ (画像/ラベル/default_split.yaml がある場所)。"
            f"未指定なら {DEFAULT_DATA_ROOT} を利用"
        ),
    )
    parser.add_argument(
        "--split-file",
        type=Path,
        default=None,
        help="split YAML のパス。未指定なら <root>/default_split.yaml",
    )
    parser.add_argument(
        "--classes",
        nargs="*",
        help="使用するクラス名のリスト。未指定ならラベル YAML の全キーから自動推定",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="data.root を含む設定 YAML (例: recon_pretrained_val_4ch.yaml)。classes は無視し、ラベル YAML から自動推定",
    )
    parser.add_argument(
        "--schema",
        type=Path,
        default=None,
        help="クラス統合スキーマ YAML (classes, label_groups, group_reduce)。指定すると classes を上書きし、label_groups で集計",
    )
    parser.add_argument(
        "--label-suffix",
        default=".yaml",
        help="ラベルファイルの拡張子 (デフォルト: .yaml)",
    )
    parser.add_argument(
        "--no-progress",
        action="store_true",
        help="tqdm プログレスバーを無効化",
    )
    parser.add_argument(
        "--calc-mean-std",
        action="store_true",
        help="画像のRGB平均・標準偏差([0,1]スケール)を計算して表示",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=None,
        help="ファイル読み込みの並列ワーカー数。未指定なら環境依存 (ThreadPoolExecutor デフォルト)",
    )
    parser.add_argument(
        "--exclude-classes",
        nargs="*",
        default=["異常なし"],
        help="平均陽性率・平均陽性クラス数の計算から除外するクラス名 (デフォルト: 異常なし)",
    )
    parser.add_argument(
        "--sort-by",
        default="total",
        help=(
            "陽性数の多い順で並べる基準。split名 (train/val/test など) または total を指定。"
            "デフォルトは total。"
        ),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    root, split_file, classes = resolve_config(args)

    group_map = None
    group_reduce = "any"
    allowed_labels = None
    if args.schema is not None:
        schema_classes, schema_groups, schema_reduce = load_schema(args.schema)
        group_map = schema_groups
        group_reduce = schema_reduce
        # allowed labels = schema classes + group sources + group keys
        allowed_labels = set(schema_classes)
        for g, members in schema_groups.items():
            allowed_labels.update(members)
            allowed_labels.add(g)
        # --classes が明示されていなければ schema の classes を採用
        if classes is None:
            classes = schema_classes

    stats = compute_stats(
        root=root,
        split_file=split_file,
        classes=classes,
        label_suffix=args.label_suffix,
        show_progress=not args.no_progress,
        calc_mean_std=args.calc_mean_std,
        num_workers=args.workers,
        exclude_classes=args.exclude_classes,
        group_map=group_map,
        group_reduce=group_reduce,
        allowed_labels=allowed_labels,
    )
    print_summary(root, split_file, stats, sort_by=args.sort_by)


if __name__ == "__main__":
    main()